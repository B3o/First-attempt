create trigger EMAILS_TRIGGER
  before insert
  on MAILS
  for each row
  declare
v_next number;
begin
  select mails_seq.nextval into v_next from dual;
  :new.id := v_next;
  insert into mail_send values(:new.id, :new.sender);
  insert into mail_receive(id, receiver) values(:new.id, :new.receiver);
end;
/

