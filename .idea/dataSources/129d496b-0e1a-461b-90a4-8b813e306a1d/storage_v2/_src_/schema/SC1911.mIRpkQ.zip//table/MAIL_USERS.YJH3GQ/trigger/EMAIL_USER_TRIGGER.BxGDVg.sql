create trigger EMAIL_USER_TRIGGER
  before insert
  on MAIL_USERS
  for each row
  declare
    v_next number;
begin
  select mails_users_seq.nextval into v_next from dual;
  :new.id := v_next;
end;
/

